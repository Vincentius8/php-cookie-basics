<?php


if(isset($_COOKIE["username"])) {
    $username = htmlspecialchars($_COOKIE["username"]);
    echo "<h3>Welcome back, $username!</h3>";
    echo '<a href="deleteCookie.php">Delete Cookie</a>';
} else {
    echo "<p>No cookie found. Please <a href='cookieForm.php'>set one here</a>.</p>";
}

?>