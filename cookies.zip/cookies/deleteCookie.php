<?php

if(isset($_COOKIE['username'])){

    setcookie("username","", time() - 3600, "/");
    echo "<p>Cookie deleted successfully.</p>";
    echo '<a href="cookieForm.php">Go back</a>';
} else {
    echo "<p>No cookie found to delete.</p>";
}
?>