<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cookie Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
  <div class="card p-4 shadow rounded-4" style="width: 22rem;">
    <h3 class="text-center mb-3">Set Cookie</h3>


    
    <form action="setCookie.php" method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Enter Username:</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Save Cookie</button>
    </form>


    <div class="text-center mt-3">
      <a href="getCookie.php" class="text-decoration-none">Check Existing Cookie</a>
    </div>


  </div>
</body>
</html>
