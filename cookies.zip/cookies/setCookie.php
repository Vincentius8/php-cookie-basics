<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = htmlspecialchars($_POST['username']);
    setcookie("username", $username,time() + 3600, "/");

    echo"cookie has been sent for user: $username";
    echo '<a href="getCookie.php">View Cookie</a>';
}

?>